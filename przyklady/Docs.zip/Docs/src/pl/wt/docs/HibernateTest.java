package pl.wt.docs;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import pl.wt.docs.model.Role;
import pl.wt.docs.model.User;
import pl.wt.docs.utils.HibernateUtils;

public class HibernateTest {

	final static Logger log = Logger.getLogger(HibernateTest.class);
	
	
	public static void main(String[] args) {
		log.info("Start");
		
		Session session = HibernateUtils.getSessionFactory().getCurrentSession();
		Transaction transaction = session.beginTransaction();
		
//		Role rola = new Role();
//		rola.setName("DELETE");
//		session.persist(rola);
//		log.info(rola);
		
		log.info("--------------------------");
		List<Role> roles = session.createQuery("SELECT u.roles FROM User u WHERE u.id=1").list();
		roles.forEach(r->log.info(r));
		log.info("--------------------------");
		
		List<User> users = session.createCriteria(User.class).list();
		users.forEach(u->log.info(u));
		log.info("--------------------------");
		User user = users.get(2);
		
//		log.info("Zmieniam: "+user);
//		user.setName("Adam X");
//		user.getRoles().add(roleDelete);
//		session.merge(user);
		
		user.getDocuments().forEach(d->log.info(d));
		log.info("--------------------------");
		Role role1 = (Role) session.createCriteria(Role.class)
				.add(Restrictions.eq("id", 1L)).uniqueResult();
		
		role1.getUsersWithRole().forEach(u->log.info(u));
		
		log.info("--------------------------");
		
		transaction.commit();
		log.info("End");
	}

}
