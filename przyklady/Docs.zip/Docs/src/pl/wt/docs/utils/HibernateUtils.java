package pl.wt.docs.utils;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtils {

	final static Logger log = Logger.getLogger(HibernateUtils.class);
	static private SessionFactory sessionFactory = null;
	
	public static SessionFactory getSessionFactory(){
		if( sessionFactory == null ){
			sessionFactory =  buildSessionFactory();
		}
		return sessionFactory;
	}
	
	private static SessionFactory buildSessionFactory() {
		try {
			return new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			log.error("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
}
